<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CC Video Advertisining</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">


  <!--External CSS-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../CC_Video_Advertisining/css/home.css" rel="stylesheet">
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"><img src="../CC_Video_Advertisining/images/logo.png" alt="Logo" style="height: 75px;"></a>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 mx-auto">
          <li class="nav-item"><a class="nav-link" href="../CC_Video_Advertisining/home.php">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="../CC_Video_Advertisining/services.html">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="../CC_Video_Advertisining/create.html">Create</a></li>
          <li class="nav-item"><a class="nav-link" href="../CC_Video_Advertisining/feedback.html">Feedback</a></li>
          <li class="nav-item"><a class="nav-link" href="../CC_Video_Advertisining/about.html">About Us</a></li>
        </ul>
        <i class="fas fa-user fa-2x"></i>
      </div>
    </div>
  </nav>

  <!-- Hero Sections -->
  <section class="hero-section d-flex flex-wrap align-items-center justify-content-center">
    <div class="hero-text">
      <p>Creative Videos<br>&<br> Powerful Impact</p>
      <button class="hero-btn">Create Your Own Video</button>
    </div>
    <div class="hero-image">
      <img src="../CC_Video_Advertisining/images/home.jpg" alt="Editing image">
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
  	 <div class="container">
		
  	 	<div class="row">
			
  	 		<div class="footer-col">
			
  	 			<h4>Video Production</h4>
  	 			<ul>
  	 				<li><a href="#">Text Animation Video Ads</a></li>
  	 				<li><a href="#">Live Performing Video Ads</a></li>
  	 				<li><a href="#">Logo animations</a></li>
  	 				<li><a href="#">Intro Video</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Other Services</h4>
  	 			<ul>
  	 				<li><a href="#">Ringing tones</a></li>
  	 				<li><a href="#">Video Ads</a></li>
  	 				<li><a href="#">Logo Design</a></li>
  	 				<li><a href="#">Flyers</a></li>
  	 				<li><a href="#">Business Cards</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>Contact Us</h4>
  	 			<ul>
  	 				<li><a href="#">Phone</a>
						<ul><li class="a">078 73 86 366</li></ul>
					</li>
  	 				<li><a href="#">Email</a>
						<ul><li class="a">chanukanirmal899@gmail.com</li></ul>
					</li>
  	 				<li><a href="#">Address</a>
						<ul><li class="a">G38,CC Vido Advertising,<br>Ruwanwella,Kegalle.</li></ul>
					</li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
				
  	 			<h4>follow us</h4>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				<a href="#"><i class="fab fa-linkedin-in"></i></a>
					
  	 			</div>
							
  	 		</div>
			
  	 	</div>
  	 </div>
  	 <div class="footer-bottom">
  	 	<p>Copyright &copy; 2025 CC Video Advertising. All rights reserved.</p>
  	 	
  </footer>
</body>
</html>
