
<?php
// Database configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'book_db';

// Connect to database
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$errors = [];
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    $full_name = $first_name . ' ' . $last_name;   

    // Validate inputs
    if (empty($first_name)) $errors[] = "First name is required";
    if (empty($last_name)) $errors[] = "Last name is required";
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $errors[] = "Email already registered";
    }
    $stmt->close();

    // If no errors, insert into database
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, address, phone, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $first_name, $last_name, $email, $address, $phone, $hashed_password);
        
        if ($stmt->execute()) {
            $success = true;
            $first_name = $last_name = $email = $address = $phone = '';
        } else {
            $errors[] = "Registration failed: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wanderlust - Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#10B981',
                        accent: '#F59E0B',
                        dark: '#1E293B',
                        light: '#F8FAFC'
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    
</head>
<body class="font-sans bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-6xl w-full rounded-xl overflow-hidden shadow-2xl">
        <div class="md:flex">
            <!-- Left Side - Travel Image -->
            <div class="hidden md:block md:w-1/2 relative bg-cover bg-center" style="background-image: url('images/registerimage.jpg');">
            <div class="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-70"></div>
            <div class="relative z-10 h-full flex flex-col justify-end p-8 text-white">
            <h2 class="text-3xl font-bold mb-2">Start Your Journey</h2>
            <p class="text-light">Join thousands of travelers exploring the world's most beautiful destinations.</p>
    </div>
</div>
            
            <!-- Right Side - Form -->
            <div class="w-full md:w-1/2 bg-white">
                <div class="p-8">
                    <h2 class="text-2xl font-bold text-dark mb-6">Create Your Account</h2>
                    
                    <?php if ($success): ?>
                        <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                            Registration successful! You can now <a href="index.php" class="text-green-700 font-medium underline">login</a>.
                        </div>
                    <?php elseif (!empty($errors)): ?>
                        <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                            <ul class="list-disc list-inside">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="register.php">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="first-name" class="block text-gray-700 mb-2">First Name</label>
                                <input type="text" id="first-name" name="first_name" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="John" value="<?php echo isset($first_name) ? htmlspecialchars($first_name) : ''; ?>">
                            </div>
                            <div>
                                <label for="last-name" class="block text-gray-700 mb-2">Last Name</label>
                                <input type="text" id="last-name" name="last_name" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="Doe" value="<?php echo isset($last_name) ? htmlspecialchars($last_name) : ''; ?>">
                            </div>
                        </div>
                        <div class="mb-4">
                            <label for="email" class="block text-gray-700 mb-2">Email Address</label>
                            <input type="email" id="email" name="email" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="your@email.com" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                        </div>
                        <div class="mb-4">
                            <label for="address" class="block text-gray-700 mb-2">Address</label>
                            <input type="text" id="address" name="address" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="123 Travel St, Adventure City" value="<?php echo isset($address) ? htmlspecialchars($address) : ''; ?>">
                        </div>
                        <div class="mb-4">
                            <label for="phone" class="block text-gray-700 mb-2">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="+1 (555) 123-4567" value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>">
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label for="password" class="block text-gray-700 mb-2">Password</label>
                                <input type="password" id="password" name="password" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="••••••••">
                            </div>
                            <div>
                                <label for="confirm-password" class="block text-gray-700 mb-2">Confirm Password</label>
                                <input type="password" id="confirm-password" name="confirm_password" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="••••••••">
                            </div>
                        </div>
                        <div class="flex items-center mb-6">
                            <input type="checkbox" id="terms" name="terms" class="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded" required>
                            <label for="terms" class="ml-2 text-gray-700">I agree to the <a href="#" class="text-primary hover:underline">Terms & Conditions</a> and <a href="#" class="text-primary hover:underline">Privacy Policy</a></label>
                        </div>
                        <button type="submit" class="w-full bg-secondary hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 transform hover:scale-105">
                            Create Account
                        </button>
                    </form>
                    <div class="mt-6 text-center">
<p class="text-sm mt-4 text-center">
    Already have an account?
    <a href="index.php" class="text-blue-500 hover:underline">Sign in</a>
</p>               </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
