<?php
session_start();
include 'config.php'; // Your DB connection file

$username_or_email = '';  // Initialize to avoid warnings
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_or_email = $_POST['username_or_email'];
    $password = $_POST['password'];

    // Prepare statement to avoid SQL Injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $username_or_email);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verify password using password_verify
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['role'] = $row['role'];

            // Redirect based on role
            if ($row['role'] === 'admin') {
                header("Location: admin_panel/dashboard.php");
                exit();
            } else {
                header("Location: home.php");
                exit();
            }
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Wanderlust</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#10B981',
                        accent: '#F59E0B',
                        dark: '#1E293B',
                        light: '#F8FAFC'
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style>
        .bg-login {
            background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
        }
        .form-container {
            backdrop-filter: blur(8px);
            background-color: rgba(255, 255, 255, 0.85);
        }
        .input-focus:focus {
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
        }
    </style>
</head>
<body class="font-sans bg-gray-100 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-6xl w-full rounded-xl overflow-hidden shadow-2xl">
        <div class="md:flex">
            <!-- Left Image -->
            <div class="hidden md:block md:w-1/2 bg-travel relative">
                <div class="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-70"></div>
                <div class="relative z-10 h-full flex flex-col justify-end p-8 text-white">
                    <h2 class="text-3xl font-bold mb-2">Welcome Back</h2>
                    <p class="text-light">Explore your next adventure with us.</p>
                </div>
            </div>

            <!-- Right Form -->
            <div class="w-full md:w-1/2 bg-white">
                <div class="p-8">
                    <h2 class="text-2xl font-bold text-dark mb-6">Sign In</h2>

                    <?php if (!empty($error)): ?>
                        <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                            <?= htmlspecialchars($error) ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-4">
                            <label class="block text-gray-700 mb-2">Full Name or Email</label>
                            <input type="text" name="username_or_email" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="username or email" value="<?= htmlspecialchars($username_or_email) ?>">
                        </div>
                        <div class="mb-6">
                            <label class="block text-gray-700 mb-2">Password</label>
                            <input type="password" name="password" class="w-full px-4 py-3 rounded-lg border border-gray-300 input-focus focus:outline-none focus:border-primary transition" placeholder="••••••••">
                        </div>
                        <div class="flex items-center justify-between mb-6">
                            <div class="flex items-center">
                                <input type="checkbox" id="remember" name="remember" class="h-4 w-4 text-primary border-gray-300 rounded">
                                <label for="remember" class="ml-2 text-gray-700">Remember me</label>
                            </div>
                            <a href="#" class="text-primary hover:underline">Forgot password?</a>
                        </div>
                        <button type="submit" class="w-full bg-primary hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 transform hover:scale-105">
                            Sign In
                        </button>
                    </form>

                    <div class="mt-6 text-center">
                        <p class="text-gray-600">Don't have an account? <a href="register.php" class="text-primary hover:underline font-medium">Register</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
