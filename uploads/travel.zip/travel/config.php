
<?php
// Database connection parameters
$host = 'localhost';      // usually localhost
$user = 'root';           // your DB username
$password = '';           // your DB password
$dbname = 'book_db';    // your database name

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
