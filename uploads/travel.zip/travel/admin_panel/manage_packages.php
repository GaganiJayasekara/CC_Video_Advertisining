<?php
// Replace these lines at the top
define('SITE_ROOT', dirname(__DIR__));
require_once SITE_ROOT . '/config.php';

if(!isset($_SESSION['admin_logged_in']) || 
   $_SESSION['ip_address'] !== $_SERVER['REMOTE_ADDR']) {
    header('Location: admin_login.php');
    exit;
}

$packages = mysqli_query($conn, "SELECT * FROM packages ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Packages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="assets/css/admin-style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar p-3">
        <h3 class="mb-4">Travel Admin</h3>
        <nav class="nav flex-column">
            <a class="nav-link" href="dashboard.php">Dashboard</a>
            <a class="nav-link" href="manage_bookings.php">Bookings</a>
            <a class="nav-link active" href="manage_packages.php">Packages</a>
            <a class="nav-link" href="manage_users.php">Users</a>
            <a class="nav-link text-danger" href="admin_logout.php">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Manage Packages</h1>
                <a href="add_package.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Package
                </a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Package Name</th>
                            <th>Destination</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($package = mysqli_fetch_assoc($packages)): ?>
                        <tr>
                            <td><?= $package['package_id'] ?></td>
                            <td><?= $package['name'] ?></td>
                            <td><?= $package['destination'] ?></td>
                            <td>$<?= number_format($package['price'], 2) ?></td>
                            <td><?= $package['duration'] ?> days</td>
                            <td>
                                <span class="badge bg-<?= $package['status'] == 'active' ? 'success' : 'danger' ?>">
                                    <?= ucfirst($package['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="edit_package.php?id=<?= $package['package_id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="delete_package.php?id=<?= $package['package_id'] ?>" 
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Delete this package?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>