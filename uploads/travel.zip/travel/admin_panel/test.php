
<?php
echo "Admin Panel Test Works!";
?>