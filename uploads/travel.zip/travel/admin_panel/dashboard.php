<?php
session_start(); // REQUIRED to access $_SESSION
include 'config.php';

// Ensure admin is logged in and IP matches
if (!isset($_SESSION['admin_logged_in']) || 
    $_SESSION['ip_address'] !== $_SERVER['REMOTE_ADDR']) {
    header('Location: index.php');
    exit;
}

// Get total bookings
$bookings = mysqli_query($conn, "SELECT COUNT(*) AS total FROM book_form");
$total_bookings = mysqli_fetch_assoc($bookings)['total'];

// Get total packages
$packages = mysqli_query($conn, "SELECT COUNT(*) AS total FROM packages");
$total_packages = mysqli_fetch_assoc($packages)['total'];

// Get total users
$users = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
$total_users = mysqli_fetch_assoc($users)['total'];

// Get total revenue
$revenue = mysqli_query($conn, "SELECT SUM(price) AS total FROM book_form ");
$total_revenue = mysqli_fetch_assoc($revenue)['total'] ?? 0;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/admin-style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar p-3">
        <h3 class="mb-4">Travel Admin</h3>
        <nav class="nav flex-column">
            <a class="nav-link active" href="dashboard.php">Dashboard</a>
            <a class="nav-link" href="manage_bookings.php">Bookings</a>
            <a class="nav-link" href="manage_packages.php">Packages</a>
            <a class="nav-link" href="manage_users.php">Users</a>
            <a class="nav-link text-danger" href="admin_logout.php">Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="container-fluid">
            <h1 class="mb-4">Dashboard Overview</h1>
            
            <div class="row g-4">
                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="card-stat card text-white bg-primary h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Bookings</h5>
                            <h2 class="card-text"><?= $total_bookings ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="card-stat card text-white bg-success h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Revenue</h5>
                            <h2 class="card-text">$<?= number_format($total_revenue, 2) ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="card-stat card text-white bg-info h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Packages</h5>
                            <h2 class="card-text"><?= $total_packages ?></h2>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-sm-6 col-xl-3">
                    <div class="card-stat card text-white bg-warning h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <h2 class="card-text"><?= $total_users ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>